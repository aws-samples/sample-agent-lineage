# ASH Scan Triage Notes — Agent Lineage

Scan: ASH v3.5.8 (awslabs/automated-security-helper), local mode, full repo.
Reports: `reports/ash.html` (readable), `reports/ash.sarif` (machine), `reports/ash.summary.txt`, `reports/ash.csv`.

## False positives (documented, no action)

| Finding | Location | Why FP |
|---|---|---|
| detect-secrets SECRET-KEYWORD | `deploy/deploy.sh:39` | Shell variable named `SECRET` that *reads* the existing CloudFormation parameter value at deploy time. No literal secret in source. |
| detect-secrets SECRET-KEYWORD | `deploy/template.yaml` (~L492) | `OriginVerifySecret` is a `NoEcho` CloudFormation *parameter name* / user-creation hint text. No literal secret in source. |
| bandit B105 (x2) | `backend/app/auth.py:42,45` | String comparisons `token_use == "id"` / `"access"` (JWT claim values), flagged as "hardcoded password". |

## Accepted / informational (LOW)

- bandit B110 (try/except/pass) in sync connectors — deliberate per-record fault
  tolerance during AWS syncs; one record failing must not abort the sync.
- bandit B311 (`random`) in `backend/app/seed.py` — demo data generation only,
  not security-sensitive.
- bandit B310 (`urllib.urlopen`) in `backend/examples/emit_event.py` and
  `integrations/otel_translator/handler.py` — example/integration scripts with
  fixed internal URLs, not part of the deployed API service.
- npm-audit findings under `frontend/node_modules/` — transitive dev-dependency
  advisories (vite/postcss); build tooling only, not shipped to production.

## Remediated after initial scan (verified by rescan: checkov 16 -> 9)

- CKV_AWS_23 (x3) — security-group rule descriptions added
- CKV_AWS_131 — ALB drops invalid HTTP headers (header-smuggling defense)
- CKV_AWS_65 — ECS Container Insights enabled
- CKV_AWS_111 — ses:SendEmail scoped to the account's SES identities (was "*")
- CKV_DOCKER_2 — container HEALTHCHECK added (python stdlib probe of /api/v1/health)

## Hardening backlog (remaining checkov HIGH — tracked, not exit-blocking)

Defense-in-depth items consistent with open threat-model entries (#2 transport
hardening, #9 audit logging). Planned as follow-up hardening:

- CKV_AWS_91 / CKV_AWS_18 / CKV_AWS_86 — ALB / S3 / CloudFront access logging
- CKV_AWS_2 / CKV_AWS_103 — HTTPS listener + TLS policy (CloudFront->ALB origin leg;
  requires custom domain + ACM certificate on the ALB)
- CKV_AWS_174 — CloudFront minimum viewer TLS: cannot be raised while using the
  default CloudFront certificate; resolves together with the custom-domain work above
- CKV_AWS_68 — WAF on CloudFront (recurring cost; revisit beyond POC)
- CKV_AWS_158 — KMS-encrypt the ECS log group
- CKV_AWS_21 — S3 bucket versioning (static frontend assets, redeployed each release)

## Remediated prior to this scan (evidence: commit 9c41741)

- ALB security group locked to CloudFront origin-facing managed prefix list
- S3 frontend bucket server-side encryption (AES256)
- Backend container runs as non-root user

## IAM Access Analyzer (Step 5)

- `iam-policies/task-role-lineage-readonly-sync.json` -> `RESULT-identity-policy.json`: no findings
- `iam-policies/task-role-trust.json` (validated as AWS::IAM::AssumeRolePolicyDocument) -> `RESULT-trust-policy.json`: no findings
- Note: `Resource: "*"` on the sync statement is required (account-wide read-only
  enumeration of AgentCore resources is the product function; List/Get/Describe +
  logs:FilterLogEvents only).
